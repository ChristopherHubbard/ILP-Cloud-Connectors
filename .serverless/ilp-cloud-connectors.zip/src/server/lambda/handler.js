"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createConnector = (event, context) => {
    console.log(event);
    console.log(context);
    return;
};
exports.getConnector = (event, context) => {
    console.log(event);
    console.log(context);
};
exports.deleteConnector = (event, context) => {
    console.log(event);
    console.log(context);
};
exports.closeChannel = (event, context) => {
    console.log(event);
    console.log(context);
};
exports.getConnectorInfo = (event, context) => {
    console.log(event);
    console.log(context);
};
exports.stopConnector = (event, context) => {
    console.log(event);
    console.log(context);
};
//# sourceMappingURL=handler.js.map